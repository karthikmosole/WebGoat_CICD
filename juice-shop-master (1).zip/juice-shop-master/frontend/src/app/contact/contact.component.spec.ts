/*
 * Copyright (c) 2014-2026 Bjoern Kimminich & the OWASP Juice Shop contributors.
 * SPDX-License-Identifier: MIT
 */

import { TranslateModule, TranslateService } from '@ngx-translate/core'
import { CaptchaService } from '../Services/captcha.service'
import { provideHttpClientTesting } from '@angular/common/http/testing'
import { UserService } from '../Services/user.service'
import { MatCardModule } from '@angular/material/card'
import { MatFormFieldModule } from '@angular/material/form-field'
import { type ComponentFixture, TestBed } from '@angular/core/testing'
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar'
import { EventEmitter } from '@angular/core'
import { ContactComponent } from './contact.component'
import { MatInputModule } from '@angular/material/input'
import { ReactiveFormsModule } from '@angular/forms'
import { FeedbackService } from '../Services/feedback.service'
import { MatSliderModule } from '@angular/material/slider'
import { of, throwError } from 'rxjs'
import { provideHttpClient, withInterceptorsFromDi } from '@angular/common/http'

describe('ContactComponent', () => {
    let component: ContactComponent
    let fixture: ComponentFixture<ContactComponent>
    let userService: any
    let feedbackService: any
    let captchaService: any
    let snackBar: any
    let translateService

    beforeEach(async () => {
        translateService = {
            get: vi.fn().mockName("TranslateService.get")
        }
        translateService.get.mockReturnValue(of({}))
        translateService.onLangChange = new EventEmitter()
        translateService.onTranslationChange = new EventEmitter()
        translateService.onFallbackLangChange = new EventEmitter()
        translateService.onDefaultLangChange = new EventEmitter()
        userService = {
            whoAmI: vi.fn().mockName("UserService.whoAmI")
        }
        userService.whoAmI.mockReturnValue(of({}))
        snackBar = {
            open: vi.fn().mockName("MatSnackBar.open")
        }
        feedbackService = {
            save: vi.fn().mockName("FeedbackService.save")
        }
        feedbackService.save.mockReturnValue(of({}))
        captchaService = {
            getCaptcha: vi.fn().mockName("CaptchaService.getCaptcha")
        }
        captchaService.getCaptcha.mockReturnValue(of({}))

        await TestBed.configureTestingModule({
            imports: [TranslateModule.forRoot(),
                ReactiveFormsModule,
                MatSliderModule,
                MatCardModule,
                MatFormFieldModule,
                MatInputModule,
                MatSnackBarModule,
                ContactComponent],
            providers: [
                { provide: UserService, useValue: userService },
                { provide: MatSnackBar, useValue: snackBar },
                { provide: FeedbackService, useValue: feedbackService },
                { provide: CaptchaService, useValue: captchaService },
                { provide: TranslateService, useValue: translateService },
                provideHttpClient(withInterceptorsFromDi()),
                provideHttpClientTesting()
            ]
        })
            .compileComponents()
    })

    beforeEach(() => {
        fixture = TestBed.createComponent(ContactComponent)
        component = fixture.componentInstance
        fixture.detectChanges()
    })

    it('should create', () => {
        expect(component).toBeTruthy()
    })

    it('should reinitizalise forms by calling resetForm', () => {
        component.feedbackControl.setValue('feedback')
        component.captchaControl.setValue('captcha')
        component.authorControl.setValue('author')
        component.resetForm()
        expect(component.feedbackControl.value).toBe('')
        expect(component.feedbackControl.pristine).toBe(true)
        expect(component.feedbackControl.untouched).toBe(true)
        expect(component.captchaControl.value).toBe('')
        expect(component.captchaControl.pristine).toBe(true)
        expect(component.captchaControl.untouched).toBe(true)
        expect(component.authorControl.value).toBe('')
        expect(component.authorControl.pristine).toBe(true)
        expect(component.authorControl.untouched).toBe(true)
    })

    it('author formControl should be disabled', () => {
        expect(component.authorControl.disabled).toBe(true)
    })

    it('should be compulsory to provide feedback', () => {
        component.feedbackControl.setValue('')
        expect(component.feedbackControl.valid).toBeFalsy()
    })

    it('feedback should not be more than 160 characters', () => {
        let str = ''
        for (let i = 0; i < 161; ++i) {
            str += 'a'
        }
        component.feedbackControl.setValue(str)
        expect(component.feedbackControl.valid).toBeFalsy()
        str = str.slice(1)
        component.feedbackControl.setValue(str)
        expect(component.feedbackControl.valid).toBe(true)
    })

    it('should be compulsory to answer the captcha', () => {
        component.captchaControl.setValue('')
        expect(component.captchaControl.valid).toBeFalsy()
        component.captchaControl.setValue('1')
        expect(component.captchaControl.valid).toBe(true)
    })

    it('should store the captcha and the captchaId on getting new captcha', () => {
        captchaService.getCaptcha.mockReturnValue(of({ captcha: 'captcha', captchaId: 2 }))
        component.getNewCaptcha()
        expect(component.captcha).toBe('captcha')
        expect(component.captchaId).toBe(2)
    })

    it('should hold the user id of the currently logged in user', () => {
        userService.whoAmI.mockReturnValue(of({ id: 42 }))
        component.ngOnInit()
        expect(component.userIdControl.value).toBe(42)
    })

    it('should hold no user id if current user is not logged in', () => {
        vi.spyOn(console, 'log').mockImplementation(() => {})
        userService.whoAmI.mockReturnValue(throwError('Error'))
        component.ngOnInit()
        expect(component.userIdControl.value).toBeUndefined()
    })

    it('should miss feedback object if retrieving currently logged in user fails', () => {
        vi.spyOn(console, 'log').mockImplementation(() => {})
        userService.whoAmI.mockReturnValue(throwError('Error'))
        component.ngOnInit()
        expect(component.feedback).toBeUndefined()
    })

    it('should log the error if retrieving currently logged in user fails', () => {
        userService.whoAmI.mockReturnValue(throwError('Error'))
        console.log = vi.fn()
        component.ngOnInit()
        expect(console.log).toHaveBeenCalledWith('Error')
    })

    it('should hold the anonymized email of the currently logged in user', () => {
        userService.whoAmI.mockReturnValue(of({ email: 'xxxx@x.xx' }))
        component.ngOnInit()
        expect(component.authorControl.value).toBe('***x@x.xx')
    })

    it('should hold anonymous placeholder for email if current user is not logged in', () => {
        userService.whoAmI.mockReturnValue(of({ user: {} }))
        component.ngOnInit()
        expect(component.authorControl.value).toBe('anonymous')
    })

    it('should populate the feedback object and send it via the feedback service on saving', () => {
        component.captchaId = 2
        component.captchaControl.setValue('2')
        component.feedbackControl.setValue('feedback')
        component.rating = 5
        component.userIdControl.setValue('2')
        component.save()
        expect(feedbackService.save).toHaveBeenCalledWith({ captchaId: 2, captcha: '2', comment: 'feedback (anonymous)', rating: 5, UserId: '2' })
    })

    it('should display thank-you message and reset feedback form on saving feedback', () => {
        feedbackService.save.mockReturnValue(of({ rating: 4 }))
        vi.spyOn(component, 'resetForm')
        vi.spyOn(component, 'ngOnInit')
        component.save()
        expect(snackBar.open).toHaveBeenCalled()
        expect(component.ngOnInit).toHaveBeenCalled()
        expect(component.resetForm).toHaveBeenCalled()
    })

    it('should display 5-star thank-you message and reset feedback form on saving 5-star feedback', () => {
        feedbackService.save.mockReturnValue(of({ rating: 5 }))
        vi.spyOn(component, 'resetForm')
        vi.spyOn(component, 'ngOnInit')
        component.save()
        expect(snackBar.open).toHaveBeenCalled()
        expect(component.ngOnInit).toHaveBeenCalled()
        expect(component.resetForm).toHaveBeenCalled()
    })

    it('should clear the form display error if saving feedback fails', () => {
        feedbackService.save.mockReturnValue(throwError({ error: 'Error' }))
        vi.spyOn(component, 'resetCaptcha')
        component.save()
        expect(snackBar.open).toHaveBeenCalled()
        expect(component.resetCaptcha).toHaveBeenCalled()
    })

    it('should clear the feedback object if saving feedback fails', () => {
        feedbackService.save.mockReturnValue(throwError({ error: 'Error' }))
        component.save()
        expect(component.feedback).toEqual({})
    })

    describe('template rendering', () => {
        it('should render the customer feedback heading, comment textarea and submit button', () => {
            const compiled: HTMLElement = fixture.nativeElement
            expect(compiled.querySelector('h1')).toBeTruthy()
            expect(compiled.querySelector('textarea#comment')).toBeTruthy()
            expect(compiled.querySelector('button#submitButton')).toBeTruthy()
        })

        it('should render the captcha challenge and captcha answer input', () => {
            component.captcha = '1+1'
            fixture.detectChanges()
            const compiled: HTMLElement = fixture.nativeElement
            expect(compiled.querySelector('code#captcha')?.textContent).toContain('1+1')
            expect(compiled.querySelector('input#captchaControl')).toBeTruthy()
        })

        it('should keep the submit button disabled while the form is invalid or rating is missing', () => {
            const compiled: HTMLElement = fixture.nativeElement
            const submit = compiled.querySelector('button#submitButton') as HTMLButtonElement
            expect(submit.disabled).toBe(true)
        })
    })
})
