/*
 * Copyright (c) 2014-2026 Bjoern Kimminich & the OWASP Juice Shop contributors.
 * SPDX-License-Identifier: MIT
 */

import { type ComponentFixture, TestBed } from '@angular/core/testing'

import { TwoFactorAuthEnterComponent } from './two-factor-auth-enter.component'
import { SearchResultComponent } from '../search-result/search-result.component'
import { UserService } from '../Services/user.service'
import { WindowRefService } from '../Services/window-ref.service'

import { ReactiveFormsModule } from '@angular/forms'
import { provideHttpClientTesting } from '@angular/common/http/testing'
import { RouterTestingModule } from '@angular/router/testing'

import { TranslateModule } from '@ngx-translate/core'
import { CookieModule, CookieService } from 'ngy-cookie'

import { MatCardModule } from '@angular/material/card'
import { MatFormFieldModule } from '@angular/material/form-field'
import { MatButtonModule } from '@angular/material/button'
import { MatInputModule } from '@angular/material/input'
import { MatCheckboxModule } from '@angular/material/checkbox'
import { MatIconModule } from '@angular/material/icon'
import { MatTableModule } from '@angular/material/table'
import { MatPaginatorModule } from '@angular/material/paginator'
import { MatDialogModule } from '@angular/material/dialog'
import { MatDividerModule } from '@angular/material/divider'
import { MatGridListModule } from '@angular/material/grid-list'
import { MatSnackBarModule } from '@angular/material/snack-bar'
import { MatTooltipModule } from '@angular/material/tooltip'

import { of, throwError } from 'rxjs'
import { TwoFactorAuthService } from '../Services/two-factor-auth-service'
import { provideHttpClient, withInterceptorsFromDi } from '@angular/common/http'

describe('TwoFactorAuthEnterComponent', () => {
    let component: TwoFactorAuthEnterComponent
    let fixture: ComponentFixture<TwoFactorAuthEnterComponent>
    let cookieService: any
    let userService: any
    let twoFactorAuthService: any

    beforeEach(async () => {
        userService = {
            login: vi.fn().mockName("UserService.login")
        }
        userService.login.mockReturnValue(of({}))
        userService.isLoggedIn = {
            next: vi.fn().mockName("userService.isLoggedIn.next")
        }
        userService.isLoggedIn.next.mockReturnValue({})
        twoFactorAuthService = {
            verify: vi.fn().mockName("TwoFactorAuthService.verify")
        }
        twoFactorAuthService.verify.mockReturnValue(of({}))

        TestBed.configureTestingModule({
            imports: [RouterTestingModule.withRoutes([
                    { path: 'search', component: SearchResultComponent }
                ]),
                ReactiveFormsModule,
                CookieModule.forRoot(),
                TranslateModule.forRoot(),
                MatCheckboxModule,
                MatFormFieldModule,
                MatCardModule,
                MatIconModule,
                MatInputModule,
                MatTableModule,
                MatPaginatorModule,
                MatDialogModule,
                MatDividerModule,
                MatButtonModule,
                MatGridListModule,
                MatSnackBarModule,
                MatTooltipModule,
                TwoFactorAuthEnterComponent, SearchResultComponent],
            providers: [
                { provide: UserService, useValue: userService },
                { provide: TwoFactorAuthService, useValue: twoFactorAuthService },
                CookieService,
                WindowRefService,
                CookieService,
                provideHttpClient(withInterceptorsFromDi()),
                provideHttpClientTesting()
            ]
        })
            .compileComponents()
        cookieService = TestBed.inject(CookieService)
    })

    beforeEach(() => {
        fixture = TestBed.createComponent(TwoFactorAuthEnterComponent)
        component = fixture.componentInstance
        fixture.detectChanges()
    })

    it('should create', () => {
        expect(component).toBeTruthy()
    })

    it('should store authentication token in cookie', () => {
        twoFactorAuthService.verify.mockReturnValue(of({ token: 'TOKEN' }))
        component.verify()

        expect(cookieService.get('token')).toBe('TOKEN')
    })

    it('should store authentication token in local storage', () => {
        twoFactorAuthService.verify.mockReturnValue(of({ token: 'TOKEN' }))
        component.verify()

        expect(localStorage.getItem('token')).toBe('TOKEN')
    })

    it('should store basket ID in session storage', () => {
        twoFactorAuthService.verify.mockReturnValue(of({ bid: 42 }))
        component.verify()

        expect(sessionStorage.getItem('bid')).toBe('42')
    })

    it('should notice error when 2FA verification fails', () => {
        twoFactorAuthService.verify.mockReturnValue(throwError({ error: 'Error' }))
        component.verify()
        expect(component.errored).toBe(true)
    })

})
